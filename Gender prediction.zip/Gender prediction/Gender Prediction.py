import re
import sys



#defineing relevent words in both sets
maleset=set(["he","his","him","he's","male","boy","businessman","man"])
femaleset=set(["she","her","hers","she's","female","daughter","woman"])



def getInput(f):
  n=int(f.readline())
  res=[]
  for i in range(n):
    res.append(f.readline().strip())
  return map(lambda s:s.lower(),res)




def getOutput(f):
  fs=[s.strip() for s in f.readlines() if len(s.strip()) != 0]
  return fs




def getString(filename):
  f=open(filename,"r")
  res=f.read()
  return res





def getAnswer(wordlist,names):
  def getAns(name):
    malen=0
    femalen=0
    allnum=0
    nlist=[]
    for i,v in enumerate(wordlist):
      if v==name:
        allnum+=1
        nlist.append(i)
        for j in range(i+1,min(i+30,len(wordlist))):
          if wordlist[j] in maleset:
            malen+=1
            break
          elif wordlist[j] in femaleset:
            femalen+=1
            break

    if malen == 0 and femalen == 0:
      return "Female"
    elif malen>=femalen:
      return "Male"
    else:
      return "Female"
  return map(getAns,names)





def getWordList():
  return map(lambda s:s.lower(),re.findall(r"[A-Za-z'-]+",getString("corpus.txt")))





def getScore(a,b):
  return float(sum(map(lambda x,y:x==y,a,b)))/len(a)





def printReport(names,a,b):
  print(getScore(a,b))
  for i in range(len(names)):
    if a[i]!=b[i]:
      print(names[i],a[i],b[i])





def test(ifilename,ofilename):
  wordlist=getWordList()
  names=getInput(open(ifilename,"r"))
  anss=getOutput(open(ofilename,"r"))
  answers=getAnswer(wordlist,names)
  printReport(names,anss,answers)





def printAnswer():
  wordlist=getWordList()
  names=getInput(sys.stdin)
  answers=getAnswer(wordlist,names)
  for i in answers:
    print(i)
printAnswer()

