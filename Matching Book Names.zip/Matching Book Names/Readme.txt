
CODE IS WRITTEN IN PYTHON 3.7.0



instruction to run the code 

$ for python
$ pip install -r requirements.txt;

$ python run "matching book names.py

"

$ for jupyter notebook
$ pip install -r requirements.txt;
$ run each shell in "matching book names.ipynb"
