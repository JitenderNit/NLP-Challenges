from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import numpy as np



N=int(input())



#book's name as input
training_set = [input() for i in range(n)]
input()
#books's description as input
testing_set = [input() for i in range(n)] 



#making text clf using countvectorizer,tfidf and naive base clf
text_clf=Pipeline([('vect',CountVectorizer()),('tfidf',TfidfTransformer()),('clf',MultinomialNB())])
y = np.arange(N)
#training text clf
text_clf.fit(training_set, y) 




#predicting the output
output=text_clf.predict(testing_set)
#printing output for each input
for i in output:
    print(i+1)

