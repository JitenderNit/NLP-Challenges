Input is not attached in this so download it. 

I was not familiar with the concept of transfer learning so i learned about it. I had  some knowledge of Neural networks but i was not able to train it.
So, I cleaned data using beautifulsoup and then simply applied tfidf though that wasn't a good fit.
Actually i was confused on whether i use supervised or un-supervised approach on the problem.
