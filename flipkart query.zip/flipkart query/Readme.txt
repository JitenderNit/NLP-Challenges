
CODE IS WRITTEN IN PYTHON 3.7.0



instruction to run the code 




The app is trained by data present in training.txt. 

$ pip install -r requirements.txt;

$ python app.py



