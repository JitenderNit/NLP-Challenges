#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import io
import numpy as np
import re
import sys

from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.svm import LinearSVC

queries = ['axe deo', 'best-seller books', 'calvin klein', 'camcorder', 'camera', 'chemistry', 'chromebook', 
           'c programming', 'data structures algorithms', 'dell laptops', 'dslr canon', 'mathematics', 
           'nike-deodrant', 'physics', 'sony cybershot', 'spoken english', 'timex watch', 'titan watch', 
           'tommy watch', 'written english']
m = len(queries)
queries_dct = {}
for i in range(m):
    queries_dct[queries[i]] = i

def readStdin():
    """Take a text file(inputfile) and returns it's text."""
    n = int(sys.stdin.readline())
    X = []
    for i in range(n):
        X.append(sys.stdin.readline().strip())
    return (X, n)

def readTrainingData(inputFilename):
    """Take a text file(inputfile) and returns it's text."""
    f = open(inputFilename, 'r')
    n = int(f.readline())
    X = []
    y = []
    for i in range(n):
        parts = f.readline().strip().split('\t')
        X.append(parts[0])
        y.append(parts[1])
    f.close()
    return (X, y, n)

(X_tr, y, n)= readTrainingData('training.txt')
(X_te, t) = readStdin()
X = list(X_tr + X_te)

feature_generator = FeatureUnion(
        transformer_list=[
            # Pipeline for pulling words features - lowercased
            ('tfidf', TfidfVectorizer(ngram_range=(1, 1), token_pattern=r'\b\w+\b', 
                                                min_df=2, 
                                                lowercase=True, norm='l2', stop_words='english')),

        ]
    )

tfidf_matrix = feature_generator.fit_transform(X)

X_tr = tfidf_matrix[0:n]
X_te = tfidf_matrix[n:]

y = np.asarray(y)

clf = SGDClassifier(alpha=0.003, n_iter=7)
clf.fit(X_tr, y)
predicted = clf.predict(X_te)

for s in predicted:
    print(s)

